from .fullapi import haar_detect, hog_detect, cnn_detect, ssd_detect
