# Bleed AI Face Detector

A Python package that lets you use 4 different face detectors by just changing a single line of code.

## Usage

First import the library then apply your desired method and get the face detections
```
import bleedefacedetector as fd

faces_list = fd.haar_detect(img)

weather-reporter -q delhi -d 3
```